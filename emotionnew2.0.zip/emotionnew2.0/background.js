// background.js
chrome.runtime.onInstalled.addListener(() => {
  console.log("Meet Emotion Analyzer installed");
});
